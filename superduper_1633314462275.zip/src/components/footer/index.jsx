import React, { useState } from 'react'
import { useMediaQuery } from "react-responsive"
import { Collapse } from 'react-collapse';



const Footer = () => {

    return (
        <footer className="footer">
            ©superduper2021. All Rights Reserved
        </footer>
    )
}

export default Footer
